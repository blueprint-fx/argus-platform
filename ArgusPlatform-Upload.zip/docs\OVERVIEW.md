﻿# Argus Platform Documentation
Multi-source public health intelligence system.
