﻿print("Python is working!")
print("Testing basic functionality...")

# Simple test
import pandas as pd
import numpy as np
print(f"Pandas version: {pd._version_}")
print(f"Numpy version: {np._version_}")
print("All imports successful!")
